<div class="htc__copyright bg__cat--5">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <div class="copyright__inner">
                    <p>Copyright© <a href="<?php echo e(asset('/home')); ?>" style="color: #c2a476">Our Marbles</a> 2019. All right reserved.</p>
                    <a href="#"><img src="<?php echo e(asset('assetss/images/others/shape/paypol.png')); ?>" alt="payment images"></a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH F:\xampp1\htdocs\ourmarbles\resources\views/partials/footer.blade.php ENDPATH**/ ?>