<script src="<?php echo e(asset('assetss/js/vendor/jquery-3.2.1.min.js')); ?>"></script>
<!-- Bootstrap framework js -->
<script src="<?php echo e(asset('assetss/js/bootstrap.min.js')); ?>"></script>
<!-- All js plugins included in this file. -->
<script src="<?php echo e(asset('assetss/js/plugins.js')); ?>"></script>
<script src="<?php echo e(asset('assetss/js/slick.min.js')); ?>"></script>
<script src="<?php echo e(asset('assetss/js/owl.carousel.min.js')); ?>"></script>
<!-- Waypoints.min.js. -->
<script src="<?php echo e(asset('assetss/js/waypoints.min.js')); ?>"></script>
<!-- Main js file that contents all jQuery plugins activation. -->
<script src="<?php echo e(asset('assetss/js/main.js')); ?>"></script>
<?php /**PATH F:\xampp1\htdocs\ourmarbles\resources\views/partials/js.blade.php ENDPATH**/ ?>