<script src="{{asset('assetss/js/vendor/jquery-3.2.1.min.js')}}"></script>
<!-- Bootstrap framework js -->
<script src="{{asset('assetss/js/bootstrap.min.js')}}"></script>
<!-- All js plugins included in this file. -->
<script src="{{asset('assetss/js/plugins.js')}}"></script>
<script src="{{asset('assetss/js/slick.min.js')}}"></script>
<script src="{{asset('assetss/js/owl.carousel.min.js')}}"></script>
<!-- Waypoints.min.js. -->
<script src="{{asset('assetss/js/waypoints.min.js')}}"></script>
<!-- Main js file that contents all jQuery plugins activation. -->
<script src="{{asset('assetss/js/main.js')}}"></script>
